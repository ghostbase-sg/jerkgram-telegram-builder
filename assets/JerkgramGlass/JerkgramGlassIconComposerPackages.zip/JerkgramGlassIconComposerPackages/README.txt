Jerkgram Glass Icon Composer Packages

These are pre-integration Xcode 26 Icon Composer packages built from the
Official Telegram iOS 12.9.2 Telegram.icon recipe.

Structure
---------
JerkgramGlassReveal.icon/
  icon.json          <- byte-for-byte Official Telegram 12.9.2
  Assets/Oval.svg    <- byte-for-byte Official Telegram 12.9.2
  Assets/Plane.svg   <- JerkgramGlassReveal FINAL canonical vector master

JerkgramGlassSolid.icon/
  icon.json          <- byte-for-byte Official Telegram 12.9.2
  Assets/Oval.svg    <- byte-for-byte Official Telegram 12.9.2
  Assets/Plane.svg   <- JerkgramGlassSolid FINAL canonical vector master

Nothing else was changed.

Important
---------
These packages have NOT yet been materialized by Apple's Xcode 26 actool in
this environment. The next canonical step is a builder-side actool/Bazel probe
against Official Telegram 12.9.2 before modifying the working tree.

CHECKSUMS.json proves that icon.json and Oval.svg are identical to the
Official Telegram resources captured in TG1292_ICON_AUDIT.
